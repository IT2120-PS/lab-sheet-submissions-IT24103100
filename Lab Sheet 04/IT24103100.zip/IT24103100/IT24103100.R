#1
setwd("C:\\Users\\it24103100\\Desktop\\IT24103100")
getwd()

branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")

#2
str(branch_data)
summary(branch_data)

#3
boxplot(branch_data$Sales_X1,
        main = "Boxplot for Sales",
        ylab = "Sales",
        col = "lightblue",
        horizontal = TRUE)

#4
print("Five-Number Summary for Advertising:\n")
print(summary(branch_data$Advertising_X2))
print("IQR for Advertising:\n")
print(IQR(branch_data$Advertising_X2))
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")

#5
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_val <- Q3 - Q1
  lower_bound <- Q1 - 1.5 * IQR_val
  upper_bound <- Q3 + 1.5 * IQR_val
  x[x < lower_bound | x > upper_bound]
}

outliers_years <- find_outliers(branch_data$Years_X3)
print("Outliers in Years (Years_X3):\n")
print(outliers_years)

